// Teodor Golisharski 6MI0600367
#pragma once

class SystemEngine
{
public: 
	static void run();
};

