// Teodor Golisharski 6MI0600367
#pragma once
#include "MyString.hpp"

bool validateName(const MyString& name);
bool validateString(const MyString& input);


