// Teodor Golisharski 6MI0600367
#include <iostream>
#include "Message.h"
#include "SystemEngine.h"

int main()
{
    SystemEngine::run();

    return 0;
}
